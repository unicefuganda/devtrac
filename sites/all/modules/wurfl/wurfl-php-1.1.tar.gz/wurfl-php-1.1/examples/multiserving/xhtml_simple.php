<?php 
echo "<?xml version='1.0'?>";
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
   <title>Hello World</title>
</head>

<body>
 <div>
   <img src="images/logo.gif" alt="wurfl" />
   <br/>
   <h1>Hello From XHTML SIMPLE</h1>
 </div>
</body>
</html>