<?php

/**
 *  test case.
 */
class WURFLPatcherTest extends PHPUnit_Framework_TestCase {
	
	/**
	 * Prepares the environment before running a test.
	 */
	protected function setUp() {		
		
	}
	
	
	function testPathDevice() {		
	}
	
	

}

